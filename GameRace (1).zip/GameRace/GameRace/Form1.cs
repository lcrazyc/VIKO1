﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameRace
{
    public partial class Form1 : Form
    {

        private Point pos;
        private bool dragging, lose = false;
        private int countCoins = 0;


        public Form1()
        {
            InitializeComponent();

            pictureBox1.MouseDown += MouseClickDown;
            pictureBox1.MouseUp += MouseClickUp;
            pictureBox1.MouseMove += MouseClickMove;
            pictureBox3.MouseDown += MouseClickDown;
            pictureBox3.MouseUp += MouseClickUp;
            pictureBox3.MouseMove += MouseClickMove;
            label1.Visible = false;
            button1.Visible = false;
            KeyPreview = true;
        }


        private void MouseClickDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            pos.X = e.X;
            pos.Y=e.Y;
        }
        private void MouseClickUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }
        private void MouseClickMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point currPoint = PointToScreen(new Point(e.X, e.Y));
                this.Location = new Point(currPoint.X - pos.X, currPoint.Y - pos.Y+pictureBox1.Top);
            }
        }
        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == (char)Keys.Escape)
            {
                this.Close();
            }
        }


        private void timer_Tick(object sender, EventArgs e)
        {
            int speed = 5;


            pictureBox1.Top += speed;
            pictureBox3.Top += speed;
            int carspeed =6;


            enemy1.Top += carspeed;
            enemy2.Top += carspeed;
            coin.Top += speed;

          
            if (pictureBox1.Top >= 500)
            {   pictureBox1.Top =0; pictureBox3.Top = -500;
            }

            if (enemy1.Top >= 650)
            {
                enemy1.Top = -130;
                Random rand = new Random();
                enemy1.Left = rand.Next(150, 300);
            }

            if (coin.Top >= 650)
            {
                coin.Top = -50;
                Random rand = new Random();
                coin.Left = rand.Next(150, 300);
            }

            if (enemy2.Top >= 650)
            {
                enemy2.Top = -400;
                Random rand = new Random();
                enemy2.Left = rand.Next(300, 560);
            }
            if(pictureBox2.Bounds.IntersectsWith(enemy1.Bounds)|| pictureBox2.Bounds.IntersectsWith(enemy2.Bounds))
            {
                timer.Enabled = false;
                label1.Visible = true;
                button1.Visible = true;
                lose = true;
            }
            if (pictureBox2.Bounds.IntersectsWith(coin.Bounds))
            {
                countCoins++;
                label2.Text = "Coins: " + countCoins.ToString();
                coin.Top = -50;
                Random rand = new Random();
                coin.Left = rand.Next(150, 300);
            }

        }



        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (lose) return;
            int speed = 8;

            if (e.KeyCode == Keys.Left || e.KeyCode == Keys.A)
            {
                if (pictureBox2.Left > 100)
                {
                    pictureBox2.Left -= speed;
                }
            }
            else if (e.KeyCode == Keys.Right || e.KeyCode == Keys.D)
            {
                if (pictureBox2.Right < 420)
                {
                    pictureBox2.Left += speed;
                }
            }
            else if (e.KeyCode == Keys.Up || e.KeyCode == Keys.W)
            {
                if (pictureBox2.Top > 0)
                {
                    pictureBox2.Top -= speed;
                }
            }
            else if (e.KeyCode == Keys.Down || e.KeyCode == Keys.S)
            {
                if (pictureBox2.Bottom < this.Height)
                {
                    pictureBox2.Top += speed;
                }
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            enemy1.Top = -130;
            enemy2.Top = -400;
            label1.Visible = false;
            button1.Visible = false;
            timer.Enabled = true;
            lose = false;
            countCoins = 0;
            label2.Text = "Coins: " + countCoins.ToString();
            coin.Top = -500;
        }
    }
}
