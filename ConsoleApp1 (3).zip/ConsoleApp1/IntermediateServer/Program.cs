﻿using IntermediateServer;
using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace SenderApplication
{
    class Program
    {
        static async Task Main(string[] args)
        {
            await StartServer();
        }

        static async Task StartServer()
        {
            try
            {
                TcpListener listener = new TcpListener(IPAddress.Any, 3038);
                listener.Start();
                Console.WriteLine("Intermediate Server started. Waiting for data...");

                while (true)
                {
                    using (TcpClient client = await listener.AcceptTcpClientAsync())
                    {
                        await HandleClient(client);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in StartServer: {ex.Message}");
            }
        }

        static async Task HandleClient(TcpClient client)
        {
            try
            {
                string? jsonData = await NetworkHelper.ReceiveDataAsync(client);
                if (jsonData == null) throw new Exception("No data received");

                // Assuming the receiver is on a different port
                using (TcpClient receiverClient = new TcpClient("localhost", 4040))
                {
                    await NetworkHelper.SendDataAsync(receiverClient, jsonData);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in HandleClient: {ex.Message}");
            }
        }
    }

    public class SignatureData
    {
        public byte[] Signature { get; set; }
        public string Text { get; set; }
        public RSAParametersData PublicKey { get; set; }
    }

    public class RSAParametersData
    {
        public byte[] Modulus { get; set; }
        public byte[] Exponent { get; set; }

        public RSAParametersData(byte[] modulus, byte[] exponent)
        {
            Modulus = modulus;
            Exponent = exponent;
        }
    }
}